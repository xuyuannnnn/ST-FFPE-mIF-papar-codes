from functools import reduce
import scanpy as sc
import pandas as pd
import tifffile as tifi

###functions
def img2grey(img):
    img = cv2.cvtColor(img,cv2.COLOR_RGB2GRAY)
    return img
def sumSignal(mask,img,id):
    y,x = np.where(mask !=0 )
    label = mask[y,x]
    gray = img[y,x]
    cellLabel = pd.DataFrame({'y':y,'x':x,'label':label,id:gray})
    cellLabel = cellLabel.groupby('label').agg({id:'sum'}).reset_index()
    return cellLabel
    
### extract cell type
adata = sc.read_h5ad('/hsfscqjf2/ST_CQ/PROJECT_Temp/zhaoxuelin/project/2024/v2mIF/03.cellcommunication/cellanno/out_07/cell2location_map_cell/sp.h5ad')
meta = adata.obs
meta.reset_index(names = 'label',inplace = True)
meta_cell_type = meta.iloc[:,[0,-1]]
### read img
CD3 = tifi.imread('/hsfscqjf2/ST_CQ/PROJECT_Temp/xuyuan2/Project/FFPE_mIF/paper/AutoRegis/mIF_ST/Y00951M3/20241029/out/M3_CD3_change_register.tif')
CK19 = tifi.imread('/hsfscqjf2/ST_CQ/PROJECT_Temp/xuyuan2/Project/FFPE_mIF/paper/AutoRegis/mIF_ST/Y00951M3/20241029/out/M3_CK19_change_register.tif')
P53 = tifi.imread('/hsfscqjf2/ST_CQ/PROJECT_Temp/xuyuan2/Project/FFPE_mIF/paper/AutoRegis/mIF_ST/Y00951M3/20241029/out/M3_P53_change_register.tif')
SMA = tifi.imread('/hsfscqjf2/ST_CQ/PROJECT_Temp/xuyuan2/Project/FFPE_mIF/paper/AutoRegis/mIF_ST/Y00951M3/20241029/out/M3_SMA_change_register.tif')
CD68 = tifi.imread('/hsfscqjf2/ST_CQ/PROJECT_Temp/xuyuan2/Project/FFPE_mIF/paper/AutoRegis/mIF_ST/Y00951M3/20241029/out/M3_CD68_register.tif')
HER2 = tifi.imread('/hsfscqjf2/ST_CQ/PROJECT_Temp/xuyuan2/Project/FFPE_mIF/paper/AutoRegis/mIF_ST/Y00951M3/20241029/out/M3_HER2_register.tif')
villin = tifi.imread('/hsfscqjf2/ST_CQ/PROJECT_Temp/xuyuan2/Project/FFPE_mIF/paper/AutoRegis/mIF_ST/Y00951M3/20241029/out/M3_villin_register.tif')
vimentin = tifi.imread('/hsfscqjf2/ST_CQ/PROJECT_Temp/xuyuan2/Project/FFPE_mIF/paper/AutoRegis/mIF_ST/Y00951M3/20241029/out/M3_vimentin_register.tif')
### RGB2GRAY
CD3_gray = img2grey(CD3)
CK19_gray = img2grey(CK19)
P53_gray = img2grey(P53)
SMA_gray = img2grey(SMA)
CD68_gray = img2grey(CD68)
HER2_gray = img2grey(HER2)
villin_gray = img2grey(villin)
vimentin_gray = img2grey(vimentin)
### calculate mIF signal
cellCD3 = sumSignal(img_expand,CD3_gray,'CD3')
cellCK19 = sumSignal(img_expand,CK19_gray,'CK19')
cellP53 = sumSignal(img_expand,P53_gray,'P53')
cellSMA = sumSignal(img_expand,SMA_gray,'SMA')
cellCD68 = sumSignal(img_expand,CD68_gray,'CD68')
cellHER2 = sumSignal(img_expand,HER2_gray,'HER2')
cellvillin = sumSignal(img_expand,villin_gray,'villin')
cellvimentin = sumSignal(img_expand,vimentin_gray,'vimentin')
###merge celltype and mIF signal
alllist = [cellCD3,cellCK19,cellP53,cellSMA,cellCD68,cellHER2,cellvillin,cellvimentin]
mIF = reduce(lambda x,y :pd.merge(x,y,on = ['label'],how = 'outer'),alllist)
mIF_info = pd.merge(mIF,meta_cell_type,on = 'label',how = 'right')
mIF_info.to_csv('../mIF/mIF_info.csv',index = False,sep = '\t')