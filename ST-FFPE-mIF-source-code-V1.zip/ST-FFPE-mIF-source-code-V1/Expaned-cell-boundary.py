import skimage as sm
import tifffile as tifi

dapi = tifi.imread('../image/mask.tif')
img_expand = sm.segmentation.expand_labels(dapi, distance=3)
