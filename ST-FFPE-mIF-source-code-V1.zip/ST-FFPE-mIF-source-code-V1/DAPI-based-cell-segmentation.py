from cellpose import io, models, utils, denoise
import os
import sys
import glog
import cv2

glog.info('Cell Seg Test...nuc')
### cyto3 测试
model1 = models.Cellpose(gpu =True ,model_type = 'nuclei')
img = io.imread(sys.argv[1])
chans = [3,0]
diams = 0
masks1, flows1, styles1, img_dn1 = model1.eval(img, diameter = diams, channels = chans, flow_threshold = 0.8)

outlines = utils.outlines_list(masks1)

glog.info('Save Fig1...')
io.imsave(f'{sys.argv[2]}/M3.DAPI.nuc.test.super.08.tif',masks1)

glog.info('Draw contours...')
cv2.drawContours(img,outlines,-1,(255,0,0),1)
io.imsave(f'{sys.argv[2]}/nuc_img_outlines_08.tif',img)

