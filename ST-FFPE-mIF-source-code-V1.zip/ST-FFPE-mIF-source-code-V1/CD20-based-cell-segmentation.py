from cellpose import io, models, utils, denoise
import os
import sys
import glog
import cv2
glog.info('Cell Seg Test...nuc')
### cyto3 测试
model1 = models.Cellpose(gpu =True ,model_type = sys.argv[3])
img = io.imread(sys.argv[1])
chans = [2,0]
diams = 0
masks1, flows1, styles1, img_dn1 = model1.eval(img, diameter = diams, channels = chans, flow_threshold = 0.5)

glog.info('Save Fig1...')
io.imsave(f'{sys.argv[2]}/lbl.de.CD20.test.tif',masks1)

outlines = utils.outlines_list(masks1)
glog.info('Draw contours...')
cv2.drawContours(img,outlines,-1,(0,0,255),1)
io.imsave(f'{sys.argv[2]}/lbl.de.CD20.outlines.tif',img)

img_dapi = io.imread('/hsfscqjf2/ST_CQ/PROJECT_Temp/xuyuan2/Project/FFPE_mIF/paper/Fig5/images/lbl_dapi_de-1.tif')
#img_dapi1 = io.imread('/hsfscqjf2/ST_CQ/PROJECT_Temp/xuyuan2/Project/FFPE_mIF/paper/Fig5/cellseg/lbl.nuc.outlines.tif')
#cv2.drawContours(img_dapi1, outlines , -1,(0,255,0),1)
cv2.drawContours(img_dapi, outlines , -1,(0,255,0),1)
io.imsave(f'{sys.argv[2]}/lbl.de.CD20.outlines_to_dapi_cell.tif',img_dapi)
