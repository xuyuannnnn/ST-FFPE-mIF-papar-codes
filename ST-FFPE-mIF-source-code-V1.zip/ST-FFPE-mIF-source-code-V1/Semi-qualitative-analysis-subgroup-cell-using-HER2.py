from sklearn import preprocessing
import pandas as pd
from tqdm import tqdm
## read data
adata = sc.read_h5ad('/hsfscqjf2/ST_CQ/PROJECT_Temp/zhaoxuelin/project/2024/v2mIF/03.cellcommunication/cellanno/out_07/cell2location_map_cell/sp.h5ad') ## annotated
mIF_info = pd.read_csv('../mIF_signals.csv')
## 
adata_meta = adata.obs.reset_index(names = 'label')
mIF_info = pd.merge(mIF_info, adata_meta, on = 'label',how = 'inner')

### subgroup cell based on HER2
mIF_info_epi = mIF_info[mIF_info.cell2loc_anno == 'Epithelial cells']
Q1 = np.percentile(mIF_info_epi.HER2,25)
Q3 = np.percentile(mIF_info_epi.HER2,75)

epi = []
for k,v in tqdm(mIF_info_epi.iterrows()):
    if v.HER2 < 983:
        epi.append('low')
    elif v.HER2 >= 983 and v.HER2 <= 8414:
        epi.append('middle')
    else:
        epi.append('high')

adata_epi = adata[adata.obs.cell2loc_anno == 'Epithelial cells']
adata_epi_obs = adata_epi.obs
adata_epi_obs['levels'] = epi
adata_epi.obs = adata_epi_obs

### calculate DEG
sc.pp.normalize_total(adata_epi,inplace=True)
sc.pp.log1p(adata_epi)
sc.pp.scale(adata_epi)
sc.tl.rank_genes_groups(adata_epi,'levels',groups = ['high'],reference='low',pts = True,method='wilcoxon',use_raw=False)
epi_genes = get_rank_genes_norest(adata_epi, 'high',0,0)
epi_genes.to_csv('/hsfscqjf2/ST_CQ/PROJECT_Temp/xuyuan2/Project/FFPE_mIF/paper/Fig5/data/CK19_HER2_levels/high2low_all.genes.csv',index =False, sep = '\t')
