library(clusterProfiler)
library(tidyverse)

genes2GSEA <- function(genes,p){
    genes <- read.csv(genes,sep = '\t')
    genes <- genes[genes$pvals < p,]
    geneList <- genes$names
    genes_bitr=bitr(geneList,fromType="SYMBOL",toType="ENTREZID",OrgDb="org.Hs.eg.db")
    genes_bitr <- dplyr::distinct(genes_bitr,SYMBOL,.keep_all=TRUE)
    colnames(genes)[1] <- 'SYMBOL'
    genes <- genes %>% inner_join(genes_bitr,by = 'SYMBOL')
    genes_for_gsea <- genes %>% arrange(desc(logfoldchanges))
    geneList = genes_for_gsea$logfoldchanges
    names(geneList) <- genes_for_gsea$ENTREZID
    return(geneList)
}

gmt <- read.gmt('/hsfscqjf2/ST_CQ/PROJECT_Temp/xuyuan2/Project/FFPE_mIF/paper/Fig5/gmt/h.all.v2024.1.Hs.entrez.gmt')
allgenes <- genes2GSEA('/hsfscqjf2/ST_CQ/PROJECT_Temp/xuyuan2/Project/FFPE_mIF/paper/Fig5/data/CK19_HER2_levels/high2low_all.genes.csv',1)
gsea_all_result <- GSEA(allgenes,TERM2GENE = gmt,pvalueCutoff = 1)
gsea_all_result <- arrange(gsea_all_result,pvalue)